@echo off
cd /d "%~dp0"
set PORT=43124
:again
echo SUROB MSI Calculator: http://127.0.0.1:%PORT%
echo Press Ctrl+C to stop.
start "" http://127.0.0.1:%PORT%
python -m http.server %PORT% --bind 127.0.0.1
if not errorlevel 1 goto :eof
py -m http.server %PORT% --bind 127.0.0.1
if not errorlevel 1 goto :eof
echo Port %PORT% is already in use. Trying the next port.
set /a PORT=PORT+1
if %PORT% GTR 43140 goto fail
goto again
:fail
echo Could not find a free port between 43124 and 43140.
exit /b 1
