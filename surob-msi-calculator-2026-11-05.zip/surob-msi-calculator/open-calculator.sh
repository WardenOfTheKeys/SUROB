#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  PY=python3
elif command -v python >/dev/null 2>&1; then
  PY=python
else
  echo "Python 3 is required to open this folder."
  exit 1
fi

open_browser() {
  if command -v open >/dev/null 2>&1; then
    open "$1" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$1" >/dev/null 2>&1 || true
  fi
}

port_free() {
  "$PY" -c 'import socket, sys
s = socket.socket()
try:
    s.bind(("127.0.0.1", int(sys.argv[1])))
except OSError:
    sys.exit(1)
finally:
    s.close()' "$1"
}

calculator_ready() {
  "$PY" -c 'import sys, urllib.request
url = "http://127.0.0.1:%s/" % sys.argv[1]
try:
    with urllib.request.urlopen(url, timeout=2) as response:
        body = response.read(8000).decode("utf-8", "replace")
except Exception:
    sys.exit(1)
sys.exit(0 if "SUROB" in body else 1)' "$1"
}

PORT=43124
if ! port_free "$PORT"; then
  if calculator_ready "$PORT"; then
    URL="http://127.0.0.1:$PORT"
    echo "SUROB MSI Calculator is already running: $URL"
    open_browser "$URL"
    exit 0
  fi
  n=43125
  while [ "$n" -le 43140 ]; do
    if port_free "$n"; then
      PORT=$n
      break
    fi
    n=$((n + 1))
  done
  if ! port_free "$PORT"; then
    echo "Could not find a free port between 43124 and 43140."
    exit 1
  fi
fi

URL="http://127.0.0.1:$PORT"
echo "SUROB MSI Calculator: $URL"
echo "Press Ctrl+C to stop."
(sleep 1; open_browser "$URL") >/dev/null 2>&1 &
exec "$PY" -m http.server "$PORT" --bind 127.0.0.1
